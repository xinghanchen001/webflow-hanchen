---
title: Tenetur Quia Rerum
slug: tenetur-quia-rerum
f_galerie:
  - url: >-
      https://uploads-ssl.webflow.com/64d397f8db7e501ca6169e82/651186694d7f47e749427c57_image8.jpeg
    alt: null
  - url: >-
      https://uploads-ssl.webflow.com/64d397f8db7e501ca6169e82/651186694d7f47e749427c7b_image15.jpeg
    alt: null
  - url: >-
      https://uploads-ssl.webflow.com/64d397f8db7e501ca6169e82/651186694d7f47e749427c51_image8.jpeg
    alt: null
  - url: >-
      https://uploads-ssl.webflow.com/64d397f8db7e501ca6169e82/651186694d7f47e749427c7e_image4.jpeg
    alt: null
updated-on: '2023-09-25T13:08:57.766Z'
created-on: '2023-09-25T13:08:57.766Z'
published-on: '2023-09-25T21:39:00.866Z'
layout: '[galerie-image].html'
tags: galerie-image
---


