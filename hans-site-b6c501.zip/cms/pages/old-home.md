---
title: Design Guidelines
permalink: '{{ page.fileSlug }}/index.html'
layout: old-home.html
slug: old-home
tags: pages
---


